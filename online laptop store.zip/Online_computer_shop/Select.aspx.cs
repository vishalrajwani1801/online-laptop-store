﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class Select : System.Web.UI.Page
{

    public string qry = "";
    public SqlCommand cmd;
    public SqlConnection cnn;
    DataTable dt;
    DataSet ds;
    SqlDataAdapter da;
    dbConnection db = new dbConnection();

    string cnstr = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=F:\Online_computer_shop\App_Data\db_Laptop_Detail.mdf;Integrated Security=True;Connect Timeout=30";
    
    protected void Page_Load(object sender, EventArgs e)
    {

        dt = db.fetch("select max(Id) from tbl_Bynow");
        string Us_Id = dt.Rows[0][0].ToString();

        int MyAdvID = 1;

        qry = "select * from cart_items ";
        cnn = new SqlConnection(cnstr);
        cmd = new SqlCommand(qry, cnn);
        da = new SqlDataAdapter(cmd);
        dt = new DataTable();
        cnn.Open();
        da.Fill(dt);
        int colm = dt.Rows.Count;
        colm = colm - 1;
     Label1.Text = colm.ToString();

        int total = 0;
        for (int i = 0; i <= colm; i++)
        {
           

            qry = "SELECT MAX(Id) + 1 FROM user_cart";
            cnn = new SqlConnection(cnstr);
            cmd = new SqlCommand(qry, cnn);
            SqlDataReader DR;
            cnn.Open();
            DR = cmd.ExecuteReader();
            if (DR.Read())
            {
                try
                {
                    MyAdvID = int.Parse(DR.GetValue(0).ToString());
                }
                catch { }
              
            }
            cnn.Close();
            cmd.Dispose();
            cnn.Dispose();
            da.Dispose();



            cnn = new SqlConnection(cnstr);
            cnn.Open();
            qry = "Insert into user_cart(Id,u_id,c_id,p_id,l_name,l_price) values (";
            qry += "'" + MyAdvID.ToString() + "',";
            qry += "'" + Us_Id + "',";
            qry += "'" + dt.Rows[i][0].ToString() + "',";
            qry += "'" + dt.Rows[i][1].ToString() + "',";
            qry += "'" + dt.Rows[i][2].ToString() + "',";
            qry += "'" + dt.Rows[i][3].ToString() + "')";


            total += Int32.Parse(dt.Rows[i][3].ToString());
            cmd = new SqlCommand(qry, cnn);
            da = new SqlDataAdapter(cmd);
            cmd.ExecuteNonQuery();
            cnn.Close();
            DR.Close();
            cmd.Dispose();
            cnn.Dispose();


         
            

        }
        Label7.Text = Convert.ToString(total);
        cnn.Close();
        cnn.Dispose();
        cmd.Dispose();
        da.Dispose();



        qry = "select * from user_cart where u_id=" + Us_Id;
        cnn = new SqlConnection(cnstr);
        cmd = new SqlCommand(qry, cnn);
        da = new SqlDataAdapter(cmd);
        ds = new DataSet();
        cnn.Open();
        da.Fill(ds);
        cnn.Close();
        cnn.Dispose();
        cmd.Dispose();
        da.Dispose();
        Repeater1.DataSource = ds;
        Repeater1.DataBind();

       dt = db.fetch("DELETE FROM cart_items");


        dt = db.fetch("select * from tbl_Bynow where Id=" + Us_Id);
        string Us_name = dt.Rows[0][1].ToString();
        Label1.Text = Us_name;


    }
   
}