﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Login : System.Web.UI.Page
{
    dbConnection db = new dbConnection();
    DataTable dt;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        string uid = TextBox1.Text;
        string pass = TextBox2.Text;
        dt = db.fetch("select * from tbl_custome where U_name ='" + uid + "' and Password='" + pass + "'");
        if (dt.Rows.Count > 0)
        {
            Response.Redirect("byNow.aspx");
        }
    }
}