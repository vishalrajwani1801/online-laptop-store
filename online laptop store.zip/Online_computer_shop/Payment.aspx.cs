﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class Payment : System.Web.UI.Page
{
    dbConnection db = new dbConnection();
    DataTable dt;
    string cnstr = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=F:\Online_computer_shop\App_Data\db_Laptop_Detail.mdf;Integrated Security=True;Connect Timeout=30";
    protected void Page_Load(object sender, EventArgs e)
    {
        int i = 1;
        while (i <= 12)
        {
            string data = i.ToString();
            DropDownList2.Items.Add(data);
            i++;
        }
        int j = 2017;
        while (j <= 2022)
        {
            string data = j.ToString();
            DropDownList3.Items.Add(data);
            j++;
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        dt = db.fetch("select max(ID) from c_payment");
        int id = int.Parse(dt.Rows[0][0].ToString()) + 1;

        string ctype = DropDownList4.SelectedItem.Text.ToString();
        string cname = DropDownList1.SelectedItem.Text.ToString();
        string edate = DropDownList2.SelectedItem.Text.ToString() + "   " + DropDownList3.SelectedItem.Text.ToString();

        string qry = "insert into c_payment (ID,C_type,C_name,C_num,E_date) values (@id,@ctype,@cname,@cnum,@edate)";
        SqlConnection cnn = new SqlConnection(cnstr);
        SqlCommand cmd = new SqlCommand(qry, cnn);
        cmd.Parameters.AddWithValue("@id", id);
        cmd.Parameters.AddWithValue("@ctype", ctype);
        cmd.Parameters.AddWithValue("@cname", cname);
        cmd.Parameters.AddWithValue("@cnum", TextBox1.Text);
        cmd.Parameters.AddWithValue("@edate", edate);


        cnn.Open();
        cmd.ExecuteNonQuery();
        cnn.Close();
        Response.Redirect("Select.aspx");
    }
}