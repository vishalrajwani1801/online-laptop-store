﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class byNow : System.Web.UI.Page
{
    DataTable dt;
    dbConnection db = new dbConnection();
    string cnstr = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=F:\Online_computer_shop\App_Data\db_Laptop_Detail.mdf;Integrated Security=True;Connect Timeout=30";

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {

        dt = db.fetch("select max(Id) from tbl_Bynow");
        int id = int.Parse(dt.Rows[0][0].ToString()) + 1;

        string qry = "insert into tbl_Bynow (Id,c_name,address,city,zip,state) values (@id,@cnmae,@add,@city,@zip,@state)";
        SqlConnection cnn = new SqlConnection(cnstr);
        SqlCommand cmd = new SqlCommand(qry, cnn);
        cmd.Parameters.AddWithValue("@id", id);
        cmd.Parameters.AddWithValue("@cnmae", TextBox1.Text);
        cmd.Parameters.AddWithValue("@add", TextBox2.Text);
        cmd.Parameters.AddWithValue("@city", TextBox3.Text);
        cmd.Parameters.AddWithValue("@zip", TextBox4.Text);
        cmd.Parameters.AddWithValue("@state", TextBox5.Text);

        cnn.Open();
        cmd.ExecuteNonQuery();
        cnn.Close();
        Response.Redirect("Payment.aspx");
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        TextBox1.Text = "";
        TextBox2.Text = "";
        TextBox3.Text = "";
        TextBox4.Text = "";
        TextBox5.Text = "";
    }
    protected void Button3_Click(object sender, EventArgs e)
    {

    }
}