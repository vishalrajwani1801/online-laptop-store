﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class Details : System.Web.UI.Page
{
    DataTable dt;
    dbConnection db = new dbConnection();
    string Id;
    protected void Page_Load(object sender, EventArgs e)
    {
         Id = Request.QueryString[0].ToString();
      

        try
        {
            dt = db.fetch("select * from tbl_laptopdetail where Id='" + Id + "'");
            string imag= dt.Rows[0][1].ToString();
            Image1.ImageUrl = imag;
            string name = dt.Rows[0][2].ToString();
            Label1.Text = name;
            string prise = dt.Rows[0][3].ToString();
            Label2.Text = prise;
            string cpu = dt.Rows[0][4].ToString();
            Label3.Text = cpu;
            string memory = dt.Rows[0][5].ToString();
            Label4.Text = memory;
            string size = dt.Rows[0][6].ToString();
            Label5.Text = size;
            string cate = dt.Rows[0][7].ToString();
            Label6.Text = cate;
            string color = dt.Rows[0][8].ToString();
            Label7.Text = color;


            
        }
        catch
        {
            
        }
       
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("AllPage.aspx?cat=" + dt.Rows[0][7].ToString());
    }
}