﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;

public partial class Main : System.Web.UI.MasterPage
{
    dbConnection db = new dbConnection();
    public DataTable dt,dt1,mc1;
    protected void Page_Load(object sender, EventArgs e)
    {
        Menu2.Items.Clear();
        dt1=db.fetch("select * from tbl_category ");
        DataRow[] drow = dt1.Select("Par_id="+0);
       
        foreach (DataRow dr in drow)
        {
            MenuItem newmenu = new MenuItem(dr[1].ToString(), dr[0].ToString());
            Menu2.Items.Add(newmenu);
        }

    }
    protected void Menu2_MenuItemClick(object sender, MenuEventArgs e)
    {
        mc1 = db.fetch("select * from tbl_category where Cat_Id='" + Menu2.SelectedValue.ToString() + "'");
        string s1 = mc1.Rows[0][1].ToString();
        Response.Redirect("AllPage.aspx?cat="+s1);

    }
}
