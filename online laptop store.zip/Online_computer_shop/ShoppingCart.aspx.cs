﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;


public partial class Cart : System.Web.UI.Page
{
    dbConnection db = new dbConnection();
    DataTable dt, mcl;
    string cnstr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {

        try
        {
            dt = db.fetch("select * from cart_items ");
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }
        catch
        {

        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("Login.aspx");
    }


    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        Label lblID = (Label)GridView1.Rows[e.RowIndex].FindControl("lblGrdID");

        string qry = "DELETE FROM cart_items ";
        qry += " WHERE C_ID = " + lblID.Text + "";

        SqlConnection CNN = new SqlConnection(cnstr);
        SqlCommand CMD = new SqlCommand(qry, CNN);
        CNN.Open();
        CMD.ExecuteNonQuery();
        CNN.Close();

        CNN.Dispose();
        CMD.Dispose();

        GridView1.EditIndex = -1;

        dt = db.fetch("select * from cart_items ");
        GridView1.DataSource = dt;
        GridView1.DataBind();
    }
}
