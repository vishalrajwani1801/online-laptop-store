﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class Search : System.Web.UI.Page
{

    dbConnection db = new dbConnection();
    DataTable dt;
    string cnstr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {

        dt = db.fetch("select max(Id) from laptop_commen");
        int id = int.Parse(dt.Rows[0][0].ToString()) + 1;
        string qry = "insert into laptop_commen (Id,C_name,E_mail,P_no,C_omm) values (@id,@cnmae,@email,@phon,@comm)";
        SqlConnection cnn = new SqlConnection(cnstr);
        SqlCommand cmd = new SqlCommand(qry, cnn);
        cmd.Parameters.AddWithValue("@id", id);
        cmd.Parameters.AddWithValue("@cnmae", TextBox1.Text);
        cmd.Parameters.AddWithValue("@email", TextBox2.Text);
        cmd.Parameters.AddWithValue("@phon", TextBox3.Text);
        cmd.Parameters.AddWithValue("@comm", TextBox4.Text);

        cnn.Open();
        cmd.ExecuteNonQuery();
        cnn.Close();

        TextBox1.Text = "";
        TextBox2.Text = "";
        TextBox3.Text = "";
        TextBox4.Text = "";

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        TextBox1.Text = "";
        TextBox2.Text = "";
        TextBox3.Text = "";
        TextBox4.Text = "";
    }
}
