﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class CreateNewAcc : System.Web.UI.Page
{
    dbConnection db = new dbConnection();
    DataTable dt;
    string cnstr = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=F:\Online_computer_shop\App_Data\db_Laptop_Detail.mdf;Integrated Security=True;Connect Timeout=30";
    protected void Page_Load(object sender, EventArgs e)
    {
       
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("Login.aspx");
       
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
       
        dt = db.fetch("select max(Us_id) from tbl_custome");
        int id=int.Parse(dt.Rows[0][0].ToString())+1;
        string qry = "insert into tbl_custome (Us_id,F_name,L_name,U_name,Password,Email_id,Mobil_no) values (@id,@fnmae,@lname,@uname,@pass,@email,@mobil)";
        SqlConnection cnn = new SqlConnection(cnstr);
        SqlCommand cmd = new SqlCommand(qry, cnn);
        cmd.Parameters.AddWithValue("@id",id);
        cmd.Parameters.AddWithValue("@fnmae", TextBox1.Text);
        cmd.Parameters.AddWithValue("@lname", TextBox2.Text);
        cmd.Parameters.AddWithValue("@uname", TextBox3.Text);
        cmd.Parameters.AddWithValue("@pass", TextBox4.Text);
        cmd.Parameters.AddWithValue("@email", TextBox5.Text);
        cmd.Parameters.AddWithValue("@mobil", TextBox6.Text);
        cnn.Open();
        cmd.ExecuteNonQuery();
        cnn.Close();
            Response.Redirect("byNow.aspx");

       
        
       
    }
}