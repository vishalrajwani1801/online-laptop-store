﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

using System.Data.SqlClient;
 using System.IO;


public partial class Insert : System.Web.UI.Page
{
    SqlConnection con;
    SqlDataAdapter da;
    DataSet ds;
    SqlCommand cmd;
    dbConnection db = new dbConnection();
    DataTable dt;
    string strCon = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        TextBox6.Visible = false;
        Button4.Visible = false;
        if (!IsPostBack)
        {
            BindGridviewData();
        }
        SqlConnection con = new SqlConnection(strCon);

        string com = "Select * from tbl_category";

        SqlDataAdapter adpt = new SqlDataAdapter(com, con);

        DataTable dt = new DataTable();

        adpt.Fill(dt);

        DropDownList1.DataSource = dt;

        DropDownList1.DataBind();

        DropDownList1.DataTextField = "Cat_name";

        DropDownList1.DataValueField = "Cat_Id";

        DropDownList1.DataBind();
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        TextBox6.Visible = true;
        Button4.Visible = true;
    }
    protected void Button4_Click(object sender, EventArgs e)
    {

        DropDownList1.Items.Add(TextBox6.Text);
              
    }
  
 

// Bind Gridview Data
private void BindGridviewData()
{
        using (SqlConnection con=new SqlConnection(strCon))
        {
                using (SqlCommand cmd=new SqlCommand())
                {
                        cmd.CommandText = "select * from tbl_laptopdetail";
                        cmd.Connection = con;
                        con.Open();
                        GridView1.DataSource = cmd.ExecuteReader();
                            GridView1.DataBind();
                            con.Close();
                   }
        }
}
// Save files to Folder and files path in database
  protected void Button1_Click(object sender, EventArgs e)
    {
        dt = db.fetch("select max(Id) from tbl_laptopdetail");
        int id = int.Parse(dt.Rows[0][0].ToString()) + 1;

               // string filename = Path.GetFileName(FileUpload1.PostedFile."~/Image/laptop/"+FileName);
                string filePath = FileUpload1.PostedFile.FileName; // file name with path.
                string file = "~/Image/laptop/" + filePath;

                string qry = "insert into tbl_laptopdetail(Id,Laptop_image,Laptop_name,Laptop_price,CPU_detail,Memory,screen_size,Laptop_catagory,Laptop_color) values(@id,@image,@name,@price,@cpu,@mem,@size,@cat,@color)";
                SqlConnection cnn = new SqlConnection(strCon);
                SqlCommand cmd = new SqlCommand(qry, cnn);
                cmd.Parameters.AddWithValue("@id", id);
                cmd.Parameters.AddWithValue("@image", file);
                cmd.Parameters.AddWithValue("@name", TextBox1.Text);
                cmd.Parameters.AddWithValue("@price", TextBox7.Text);
                cmd.Parameters.AddWithValue("@cpu", TextBox4.Text);
                cmd.Parameters.AddWithValue("@mem", TextBox3.Text);
                cmd.Parameters.AddWithValue("@size", TextBox2.Text);
                cmd.Parameters.AddWithValue("@cat", DropDownList1.SelectedIndex.ToString());
                cmd.Parameters.AddWithValue("@color", TextBox5.Text);               
              
                cnn.Open();
                cmd.ExecuteNonQuery();
                ImageData();  
                cnn.Close();
                BindGridviewData();
                
               }
  protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
  {
      
  }
  protected void ImageData()
  {
      con = new SqlConnection(strCon);
      con.Open();
      da = new SqlDataAdapter("select * from tbl_laptopdetail", con);
      ds = new DataSet();
      da.Fill(ds);
      GridView1.DataSource = ds;
      GridView1.DataBind();
  }

  protected void Gridview1_RowDeleting(object sender, GridViewDeleteEventArgs e)
  {
      GridViewRow row = (GridViewRow)GridView1.Rows[e.RowIndex];
      Label delete = (Label)row.FindControl("lbldeleteid");  
      con = new SqlConnection(strCon);
      con.Open();
      //SqlCommand cmd = new SqlCommand("Delete FROM tbl_laptopdetail where Id='" + Convert.ToInt32(GridView1.DataKeys[e.RowIndex].Value.ToString()) + "'", con);
      SqlCommand cmd = new SqlCommand("DELETE FROM tbl_laptopdetail WHERE Id'" + Convert.ToInt32(GridView1.DataKeys[e.RowIndex].Value.ToString()) + "'", con);
      cmd.ExecuteNonQuery();
      con.Close();
  } 
}
    

