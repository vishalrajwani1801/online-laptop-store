﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Admin_login : System.Web.UI.Page
{
    dbConnection db = new dbConnection();
    DataTable dt;
    
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        string uid = TextBox1.Text;
        string pass = TextBox2.Text;
        dt = db.fetch("select * from laptop_admin where User_name ='" + uid + "' and Password='" + pass + "'");
        if (dt.Rows.Count > 0)
        {
            Response.Redirect("Admin_home.aspx");
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        TextBox1.Text = "";
        TextBox2.Text = "";
    }
}