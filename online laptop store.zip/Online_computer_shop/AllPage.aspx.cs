﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;

public partial class AllPage : System.Web.UI.Page
{
    dbConnection db = new dbConnection();
    DataTable dt, mcl;
    string cat;
    string cnstr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        cat = Request.QueryString[0].ToString();
        lbldata.Text = cat;

        try
        {
            dt = db.fetch("select * from tbl_laptopdetail where Laptop_catagory='" + cat + "'");
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }
        catch
        {
            lbldata.Text = "No record found";
        }

    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        string id = GridView1.SelectedRow.Cells[0].Text;
        Response.Redirect("Details.aspx?id=" + id);
    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {

        if (e.CommandName == "AddtoCart")
        {

            int cartId = Convert.ToInt32(e.CommandArgument) + 1;
            dt = db.fetch("select * from tbl_laptopdetail where Id='" + cartId + "'");
            string c_ID = dt.Rows[0][0].ToString();
            string c_name = dt.Rows[0][2].ToString();
            string c_Prise = dt.Rows[0][3].ToString();

            SqlConnection con = new SqlConnection(cnstr);
            string qry = "select count(*) from cart_items";
            SqlCommand com = new SqlCommand(qry, con);
            con.Open();
            int count = Convert.ToInt16(com.ExecuteScalar()) + 1;
            con.Close();


            qry = "insert into cart_items (C_ID,ID,l_name,l_price) values (@cid,@id,@lname,@lprice)";
            SqlConnection cnn = new SqlConnection(cnstr);
            SqlCommand cmd = new SqlCommand(qry, cnn);
            cmd.Parameters.AddWithValue("@cid", count);
            cmd.Parameters.AddWithValue("@id", c_ID);
            cmd.Parameters.AddWithValue("@lname", c_name);
            cmd.Parameters.AddWithValue("@lprice", c_Prise);

            cnn.Open();
            cmd.ExecuteNonQuery();
            cnn.Close();
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        Button b = (Button)sender;
        int cartId = Convert.ToInt32(b.CommandArgument);
        dt = db.fetch("select * from tbl_laptopdetail where Id='" + cartId + "'");
        string c_ID = dt.Rows[0][0].ToString();
        string c_name = dt.Rows[0][2].ToString();
        string c_Prise = dt.Rows[0][3].ToString();

        SqlConnection con = new SqlConnection(cnstr);
        string qry = "select count(*) from cart_items";
        SqlCommand com = new SqlCommand(qry, con);
        con.Open();
        int count = Convert.ToInt16(com.ExecuteScalar()) + 1;
        con.Close();


        qry = "insert into cart_items (C_ID,ID,l_name,l_price) values (@cid,@id,@lname,@lprice)";
        SqlConnection cnn = new SqlConnection(cnstr);
        SqlCommand cmd = new SqlCommand(qry, cnn);
        cmd.Parameters.AddWithValue("@cid", count);
        cmd.Parameters.AddWithValue("@id", c_ID);
        cmd.Parameters.AddWithValue("@lname", c_name);
        cmd.Parameters.AddWithValue("@lprice", c_Prise);

        cnn.Open();
        cmd.ExecuteNonQuery();
        cnn.Close();
    }
}