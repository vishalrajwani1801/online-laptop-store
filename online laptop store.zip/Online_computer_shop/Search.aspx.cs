﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

using System.Data.SqlClient;



public partial class Search : System.Web.UI.Page
{
    dbConnection db = new dbConnection();
    DataTable dt, mcl;
    string cat;
    string cnstr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        dt = db.fetch("SELECT * FROM tbl_laptopdetail WHERE Laptop_name='" + TextBox1.Text + "'");
        GridView1.DataSource = dt;
        GridView1.DataBind();

    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        string id = GridView1.SelectedRow.Cells[0].Text;
        Response.Redirect("Details.aspx?id=" + id);
    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "AddtoCart")
        {
            int cartId = Convert.ToInt32(e.CommandArgument) + 1;
            dt = db.fetch("select * from tbl_laptopdetail where Id='" + cartId + "'");
            string c_ID = dt.Rows[0][0].ToString();
            string c_name = dt.Rows[0][2].ToString();
            string c_Prise = dt.Rows[0][3].ToString();


            dt = db.fetch("select max(c_id) from cart_items");
            int id = int.Parse(dt.Rows[0][0].ToString()) + 1;

            string qry = "insert into cart_items (C_ID,ID,l_name,l_price) values (@cid,@id,@lname,@lprice)";
            SqlConnection cnn = new SqlConnection(cnstr);
            SqlCommand cmd = new SqlCommand(qry, cnn);
            cmd.Parameters.AddWithValue("@cid", id);
            cmd.Parameters.AddWithValue("@id", c_ID);
            cmd.Parameters.AddWithValue("@lname", c_name);
            cmd.Parameters.AddWithValue("@lprice", c_Prise);

            cnn.Open();
            cmd.ExecuteNonQuery();
            cnn.Close();
        }
    }
}
