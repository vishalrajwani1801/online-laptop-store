﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;


public class dbConnection
{
    string strCon = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
    
    public DataTable fetch(string qry)
    {
        SqlDataAdapter da = new SqlDataAdapter(qry, strCon);
        DataTable dt = new DataTable();
        da.Fill(dt);
        return dt;
    }

	
}